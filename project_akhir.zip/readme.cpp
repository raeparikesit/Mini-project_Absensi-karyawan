---------
struktur
---------

dashboard
koneksi-absensi
login
cek_login
register
proses-signup
logout

--------
admin
--------

halaman_admin
absensi_admin
proses-reset_absensi
update_datapegawai
proses-update_datapegawai
delete_datapegawai

--------
pegawai
--------

halaman_pegawai
informasi_pegawai
proses-absensi_pegawai



