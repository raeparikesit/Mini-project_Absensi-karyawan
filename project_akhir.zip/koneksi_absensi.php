<?php
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $database = "absensi";

    $koneksi = new mysqli($hostname, $username, $password, $database);
?>